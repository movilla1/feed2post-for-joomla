<?php
/**
 * Feed2post v3.0
 * @author Mario O. Villarroel
 * @copyright 2010 - Elcan Software
 * @license GPLv2
 * 
 * Main defines, do not edit them unless you know exactly what you're doing
 */
defined("F2PIMAGEPATH") or define ("F2PIMAGEPATH",JPATH_BASE.DS."media".DS."com_feed2post");
defined("_ROWS_PER_SEG") or define("_ROWS_PER_SEG", 30);

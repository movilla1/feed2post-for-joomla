DROP TABLE IF EXISTS `#__feed2post`;
DROP TABLE IF EXISTS `#__feed2post_config`;
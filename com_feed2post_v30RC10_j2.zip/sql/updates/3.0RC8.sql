ALTER TABLE `#__feed2post` ADD `includelink` TINYINT( 1 ) NOT NULL DEFAULT '0';
ALTER TABLE `#__feed2post` ADD `replaceimgs` TINYINT( 1 ) NOT NULL DEFAULT '0';
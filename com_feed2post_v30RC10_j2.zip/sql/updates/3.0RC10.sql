ALTER TABLE `#__feed2post_config` ADD UNIQUE `onlyone` ( `name` );
